### How to install the extension ? 

- Open Chrome and navigate to chrome://extensions/
- Enable "Developer mode" at the top right
- Click "Load unpacked" and select the extension folder

Tadaaa ! 